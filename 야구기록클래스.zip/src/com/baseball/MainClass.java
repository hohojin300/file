package com.baseball;

public class MainClass {
	public static void main(String[] args) {
		BaseBallManager m=
				new BaseBallManager();
		m.baseballAllData();
/*		for(BaseBallVO vo:m.bvo) {
			System.out.println(vo.name+":"+vo.avg);
		}*/
	}
}
