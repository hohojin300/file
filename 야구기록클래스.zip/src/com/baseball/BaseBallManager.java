package com.baseball;

import java.util.Iterator;
import java.util.StringTokenizer;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class BaseBallManager {
	BaseBallVO[] bvo=new BaseBallVO[30];
	void baseballAllData() {
		try {
			for(int i=0;i<30;i++) {
				bvo[i]=new BaseBallVO();
			}
			
			Document doc=Jsoup.connect("https://www.koreabaseball.com/Record/Player/HitterBasic/Basic1.aspx").get();
			Elements elems=doc.select("tbody tr");
			
			Iterator<Element> it=elems.listIterator();
			int i=0;
			while(it.hasNext()) {
				Element e=it.next();
				
				StringTokenizer st=new StringTokenizer(e.text());
				System.out.println(e.text());
			}
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
}












