package com.abstractDemo;

public class AbsLabDemo extends AbsLab2{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbsLabDemo ad=new AbsLabDemo();
		System.out.println("ad.getA(): "+ad.getA());
		System.out.println("ad.getStr(): "+ad.getStr());
	}

	@Override
	public String getStr() {
		// TODO Auto-generated method stub
		return str;
	}

}
