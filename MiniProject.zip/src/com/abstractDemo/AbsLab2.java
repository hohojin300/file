package com.abstractDemo;

public abstract class AbsLab2 extends AbsLab {
	@Override
	public int getA() {
		// TODO Auto-generated method stub
		return a;
	}
	public abstract String getStr();
}
