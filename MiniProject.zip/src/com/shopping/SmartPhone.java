package com.shopping;

//Product �߻�Ŭ������ ��ӹ޾� ������ SmartPhone
public class SmartPhone extends Product{
	String carrier;
	
	public SmartPhone(String pname,int price,String carrier) {
		this.pname=pname;
		this.price=price;
		this.carrier=carrier;
	}
	
	@Override
	public void printExtra() {
		// TODO Auto-generated method stub
		System.out.println("��Ż�: "+carrier);
	}
	
}






