package com.oop.inher;

public class CellPhoneLab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CellPhone smart=
				new SmartPhone("iphoneX", "010-1234-5678", 60, "1000");
		CellPhone table=
				new TabletPhone("iPad Pro", "010-3456-7890", 80, 2000);
		
		System.out.println(smart.getModel()+" "
				+smart.getNumber()+" "
				+smart.getChord());
		
	}

}
