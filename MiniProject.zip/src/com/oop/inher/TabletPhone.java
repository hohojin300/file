package com.oop.inher;

public class TabletPhone extends CellPhone{
	int size;		//���� �뷮
	public TabletPhone(String model,String number,int chord,int size) {
		this.model=model;
		this.number=number;
		this.chord=chord;
		this.size=size;
	}
}
